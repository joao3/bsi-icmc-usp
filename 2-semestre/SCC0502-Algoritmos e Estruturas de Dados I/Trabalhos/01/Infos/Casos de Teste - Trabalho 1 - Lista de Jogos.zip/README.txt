Arquivo zip gerado em: 03/12/2021 23:44:56 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 1 - Lista de Jogos