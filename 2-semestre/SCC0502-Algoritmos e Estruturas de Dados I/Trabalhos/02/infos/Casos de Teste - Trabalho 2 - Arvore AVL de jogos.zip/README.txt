Arquivo zip gerado em: 03/12/2021 23:53:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 2 - Arvore AVL de jogos